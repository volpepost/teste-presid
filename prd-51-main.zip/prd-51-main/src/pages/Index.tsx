
import React from 'react';
import IndexPageLayout from '@/components/index/IndexPageLayout';

const Index = () => {
  return (
    <IndexPageLayout />
  );
};

export default Index;
