// Barrel exports for shared components
export { default as BaseSection } from './BaseSection';
export { default as SectionCard } from './SectionCard';